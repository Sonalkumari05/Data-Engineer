import pandas as pd

def clean_csv_data(supplement_df):
    extracted_data = []

    # Iterate over each row in the DataFrame
    for index, row in supplement_df.iterrows():
    # Extract the first two columns
        first_two_cols = row[:2].tolist()
    
    # Check if ']' is in product_name
        if ']' in row['product_name']:
        # Create the modified row and append to the list
            modified_row = first_two_cols + [str(row['Unnamed_3']) + ", \"" + str(row['product_id']) + "\", \"" + str(row['product_name']) + "\""] + row[5:].tolist()
            extracted_data.append(modified_row)
    
    # Check if ']' is in ingredients
        elif ']' in row['ingredients']:
            # Create the modified row and append to the list
            modified_row = first_two_cols + [str(row['Unnamed_3']) + ", \"" + str(row['product_id']) + "\", \"" + str(row['product_name']) + "\", \"" + str(row['ingredients']) + "\""] + row[6:].tolist()
            extracted_data.append(modified_row)

    df = pd.DataFrame(extracted_data)
    
    df.drop(columns=[10], inplace=True)
    df.columns = ['product_id', 'product_name', 'ingredients', 
                'dosage_form', 'manufacturer', 'serving_size', 'unit_price', 
                'stock_level', 'expiry_date', 'certifications']
    df['ingredients'] = df['ingredients'].str.replace(']"', "\"]")
    df['ingredients'] = df['ingredients'].apply(eval)
    df['certifications'] = df['certifications'].apply(eval)
    df['serving_size'] = df['serving_size'].astype(int)
    df['stock_level'] = df['stock_level'].astype(int)
    df['product_id'] = df['product_id'].astype(int)
    df['unit_price'] = df['unit_price'].astype(float)
    df['expiry_date'] = pd.to_datetime(df['expiry_date'])
    return df
    

def clean_text_data(data):
    abstracts = data.split('Abstract ID:')
    extracted_data = []

    for abstract in abstracts[1:]:
        abstract_id = abstract.split('Title:')[0].strip()
        title = abstract.split('Title:')[1].split('Authors:')[0].strip()
        authors = abstract.split('Authors:')[1].split('Journal:')[0].strip()
        journal = abstract.split('Journal:')[1].split('Impact Factor:')[0].strip()
        impact_factor = float(abstract.split('Impact Factor:')[1].split('Year:')[0].strip())
        year = int(abstract.split('Year:')[1].split('Abstract:')[0].strip())
        abstract_text = abstract.split('Abstract:')[1].split('Keywords:')[0].strip()
        keywords = abstract.split('Keywords:')[1].split('DOI:')[0].strip()
        doi = abstract.split('DOI:')[1].strip()

        extracted_data.append({
            "Abstract ID": abstract_id,
            "Title": title,
            "Authors": authors,
            "Journal": journal,
            "Impact Factor": impact_factor,
            "Year": year,
            "Abstract": abstract_text,
            "Keywords": keywords,
            "DOI": doi
        })

    df = pd.DataFrame(extracted_data)
    return df