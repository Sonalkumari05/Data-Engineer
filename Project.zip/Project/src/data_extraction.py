import pandas as pd
import json

def load_csv(file_path):    
    column_names = ['Unnamed_1', 'Unnamed_2', 'Unnamed_3', 'product_id', 'product_name', 'ingredients', 
                'dosage_form', 'manufacturer', 'serving_size', 'unit_price', 
                'stock_level', 'expiry_date', 'certifications']

    supplement_df = pd.read_csv(file_path, names=column_names, skiprows=1)

    return supplement_df

def load_json(file_path):
    with open(file_path) as f:
        return json.load(f)

def load_text(file_path):
    with open(file_path, 'r') as file:
        data = file.read()

    return data
