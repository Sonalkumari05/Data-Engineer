
import pandas as pd

def link_supp_trials(supplement_df, trilas_df):
    data = []
    for index, row in supplement_df.iterrows():
        lst = []
        product_id = row["product_id"]
        for ingredient in row['ingredients']:
            if ingredient in trilas_df["ingredient"].tolist():
                indices = trilas_df.index[trilas_df['ingredient'] == ingredient].tolist()
                trial_index = indices[0]
                trial_id = trilas_df.iloc[trial_index]['trial_id']
                lst.append(trial_id)
                
        data.append([product_id, lst])
    
    return pd.DataFrame(data, columns= ['product_id', 'trial_ids'])
            
            
        

def ingredient_efficacy_rate(trilas_df):
    df = pd.DataFrame()
    df['ingredient'] = trilas_df['ingredient']
    df['efficacy_score'] = trilas_df['efficacy_metrics.efficacy_rate']
    return df