# Data Engineering Technical Assessment - StealthX AI

## Overview
This project involves processing herbal supplement data from multiple sources, cleaning and structuring the data, and preparing it for analysis. The data includes product information, clinical trial results, and research paper abstracts.

## Project Structure


## Setup Instructions
1. Clone the repository:
    ```bash
    git clone https://github.com/Sonalkumari05/Data-Engineer.git
    cd your-repo
    ```

2. Create a virtual environment and activate it:
    ```bash
    python3 -m venv env
    source env/bin/activate  # On Windows use `env\Scripts\activate`
    ```

3. Install the required packages:
    ```bash
    pip install -r requirements.txt
    ```

## Data Extraction
- The `data_extraction.py` script handles loading data from CSV, JSON, and text files.
- Make sure to place your data files in the `data/raw/` directory.

## Data Cleaning
- The `data_cleaning.py` script processes the raw data, handling missing values and standardizing ingredient names.

## Data Transformation
- The `data_transformation.py` script creates a unified ingredient database, links clinical trials with products, generates ingredient efficacy scores, and structures research findings.

## Exploration Notebook
- The `exploration.ipynb` notebook provides a detailed analysis and exploratory work on the data, including visualizations and initial insights.

## Running the Scripts
- Ensure that your data files are in the correct directories.
- Run the data processing pipeline:
    ```bash
    python src/data_extraction.py
    python src/data_cleaning.py
    python src/data_transformation.py
    ```

## Processed Datasets
- Cleaned and structured data files are saved in the `data/processed/` directory.


## Contributors
- Sonal Kumari (sonalkumari00555@gmail.com)

